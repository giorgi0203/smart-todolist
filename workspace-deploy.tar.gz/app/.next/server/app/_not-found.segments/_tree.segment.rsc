:HL["/_next/static/css/1352c10ccbb0defd.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"_not-found","h":96,"c":"$Q2"}]]
0:{"b":"c7eY0_cUt5IEacn7LKN9h","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
